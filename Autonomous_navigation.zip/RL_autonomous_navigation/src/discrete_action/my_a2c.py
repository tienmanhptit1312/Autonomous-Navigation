import gym
import numpy as np
import itertools
import rospy
import rospkg
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
sys.path.append(os.path.realpath(os.getcwd()))
from Configuration import my_turtlebot2_maze
from ActorNetwork import Actor
from CriticNetwork import Critic
import tensorflow as tf
from memory import Buffer_Memory
from collections import namedtuple
import argparse
import datetime
from noise import *
from noise import OrnsteinUhlenbeckActionNoise
# import psutil
import time


def set_param(ros):
    ros.set_param("/turtlebot2/n_actions", 3)
    ros.set_param("/turtlebot2/alpha", alpha)
    ros.set_param("/turtlebot2/epsilon", epsilon)
    ros.set_param("/turtlebot2/gamma", gamma)
    ros.set_param("/turtlebot2/epsilon_discount", epsilon_discount)
    ros.set_param("/turtlebot2/nepisodes", nepisodes)
    ros.set_param("/turtlebot2/nsteps", nstep)
    ros.set_param("/turtlebot2/running_step", running_steps)
    ros.set_param("/turtlebot2/linear_forward_speed", 0.5)
    ros.set_param("/turtlebot2/linear_turn_speed", 0.1)
    ros.set_param("/turtlebot2/angular_speed", 0.3)
    ros.set_param("/turtlebot2/init_linear_forward_speed", 0.0)
    ros.set_param("/turtlebot2/init_linear_turn_speed", 0.0)
    ros.set_param("/turtlebot2/new_ranges", 5)
    ros.set_param("/turtlebot2/min_range", 0.5)
    ros.set_param("/turtlebot2/max_laser_value", 6.0)
    ros.set_param("/turtlebot2/min_laser_value", 0.0)

    ros.set_param("/turtlebot2/number_of_sectors", 3)
    ros.set_param("/turtlebot2/min_range", 0.5)
    ros.set_param("/turtlebot2/middle_range", 1.0)
    ros.set_param("/turtlebot2/danger_laser_value", 2)
    ros.set_param("/turtlebot2/middle_laser_value", 1)
    ros.set_param("/turtlebot2/safe_laser_value", 0)
    ros.set_param("/turtlebot2/forwards_reward", 5)
    ros.set_param("/turtlebot2/turn_reward", 1)
    ros.set_param("/turtlebot2/end_episode_points", 200)


def build_summaries():
    episode_reward = tf.Variable(0.)
    tf.summary.scalar('Reward', episode_reward)
    episode_critic_loss = tf.Variable(0.)
    tf.summary.scalar('Critic_loss', episode_critic_loss)
    episode_actor_loss = tf.Variable(0.)
    tf.summary.scalar('Actor_loss', episode_actor_loss)

    summary_vars = [episode_reward, episode_critic_loss, episode_actor_loss]
    summary_ops = tf.summary.merge_all()
    return summary_ops, summary_vars


def utilizes(env, args, file_path, discount_factor=0.99, load=False):
    with tf.Session() as sess:
        epsilon_rand = 0.99
        epsilon_rand_discount = 0.0001
        counter = 0
        step_counter = 0
        action_size = 1
        state_size =12

        actor = Actor(sess=sess, init=True)
        num_actor_var = actor.get_num_trainable_vars()
        critic = Critic(sess=sess, num_trainable_vars=num_actor_var, init=True)

        summary_ops, summary_vars = build_summaries()

        writer = tf.summary.FileWriter(args['summary_dir'], tf.get_default_graph())
        # tf.get_default_graph().finalize()
        actor.update_target_network_2()
        critic.update_target_network_2()
        # actor.update_pertubed()
        using_adaptive_noise = False
        batch_size = int(args['minibatch_size'])
        replay_buffer = Buffer_Memory(batch_size=batch_size)
        Transition = namedtuple("Transition", ['state', 'action', 'reward', 'next_state'])
        i_ep = 0
        noise = OrnsteinUhlenbeckActionNoise(mu=np.zeros(action_size))
        adaptive_noise = AdaptiveParameterNoise()




        # global graph
        # graph = tf.get_default_graph()
        saver = tf.train.Saver(max_to_keep=10)
        if load:
            saver.restore(sess, file_path)
        else:
            sess.run(tf.global_variables_initializer())
        tf.get_default_graph().finalize()
        saver.save(sess, '/home/manh/Desktop/model2/testtttt2/initalized_model.ckpt')
        max_episode = 5000
        # while True:
        while True:
            rospy.logwarn("===========The Value of random factor: %.4f" % epsilon_rand)
            state = env.reset()
            # env.create_goal()
            ep_reward = 0
            ep_critic_loss = 0
            ep_actor_loss = 0
            noise.reset()
            episode = []
            if using_adaptive_noise:
                actor.update_pertubed()
                actor.pertub_param(adaptive_noise.current_stddev)
            for t in range(0, 600):
                #############################################             ###########################################

                if using_adaptive_noise:
                    action = actor.predict_pertubed_network(state)
                else:
                    action = actor.predict(state) + noise()
                    action = np.clip(action, -1, 1)
                    # action[0][0] = np.clip(action[0][0], 0.1, 0.3)
                    # action[0][1] = np.clip(action[0][1], -1, 1)

                # action = env.action_space.sample()
                # action = 0
                ###########################################             #####################################################

                next_state, reward, done, _ = env.step(action)
                t_start = time.time()

                rospy.logwarn("Reward:" + str(reward))
                replay_buffer.add(state, action, reward, next_state, done)

                if replay_buffer.get_size() > batch_size:
                    s_batch, action_batch, reward_batch, next_state_batch, is_done_batch = replay_buffer.get_batch()

                    # calculate the Q-target
                    next_state_batch = np.array(next_state_batch)
                    next_state_batch = np.reshape(next_state_batch, (batch_size, state_size))
                    # print("next_state_batch"+str(s_batch))
                    target_action_batch = actor.predict_target(next_state_batch)
                    # target_action_batch = [np.random.choice([0, 1, 2], p=target_action_batch[x]) for x in range(30)]
                    target_action_batch = np.reshape(target_action_batch, (batch_size, action_size))
                    # target_action_batch =
                    target_q = critic.predict_target(next_state_batch, target_action_batch)
                    # print('target_q'+str(target_q))
                    y_i = []
                    ######--------------t_start
                    for k in range(0, batch_size):
                        if is_done_batch[k]:
                            y_i.append(reward_batch[k])
                        else:
                            y_i.append(reward_batch[k] + critic.gamma * target_q[k])
                        # print('the size of y_i' + str(len(y_i)))
                        # update the critic network using TD
                    s_batch = np.array(s_batch)
                    s_batch = np.reshape(s_batch, (batch_size, state_size))
                    y_i = np.array(y_i)  # array of TD value
                    y_i = np.reshape(y_i, (batch_size, 1))
                    action_batch = np.array(action_batch)
                    action_batch = np.reshape(action_batch, (batch_size, action_size))
                    # critic_loss = critic.learn(s_batch, target=y_i, action=action_batch)
                    critic_loss = critic.train(s_batch, action_batch, y_i)
                    ep_critic_loss += critic_loss

                    # update the actor network using sample gradient
                    a_for_grad = actor.predict(s_batch)

                    grads = critic.gradients(state=s_batch, action=a_for_grad)
                    # grads = np.reshape(grads, (-1, 2))

                    actor_loss = actor.train(s_batch, grads)

                    # print(actor_loss)
                    # ep_actor_loss += actor_loss

                    # update target network
                    actor.update_target_network()
                    critic.update_target_network()

                state = next_state
                ep_reward += reward

                if done or t==199:
                    summary_stats = sess.run(summary_ops, feed_dict={
                        summary_vars[0]: ep_reward,
                        summary_vars[1]: ep_critic_loss,
                        summary_vars[2]: ep_actor_loss
                    })
                    writer.add_summary(summary_stats, i_ep)
                    writer.flush()
                    print('| Reward: {:d} | Episode: {:d} | Critic_loss: {:.4f} | Actor_loss: {:.4f}' \
                          .format(int(ep_reward), i_ep, ep_critic_loss, ep_actor_loss))
                    break
                t_end = time.time()
                t_comp = t_end - t_start
                # print('time to compute: -----' + str(t_comp) + '-----------------')
                counter += 1
                step_counter +=1


                # noise.reset()

            # summary_stats = sess.run(summary_ops, feed_dict={
            #     summary_vars[0]: ep_reward,
            #     summary_vars[1]: ep_critic_loss,
            #     summary_vars[2]: ep_actor_loss
            # })
            # writer.add_summary(summary_stats, i_ep)
            # writer.flush()
            # print('| Reward: {:d} | Episode: {:d} | Critic_loss: {:.4f} | Actor_loss: {:.4f}' \
            #       .format(int(ep_reward), i_ep, ep_critic_loss, ep_actor_loss))
            # if ep_reward > 1200:
            #     print("achieve the goal")
            # saver.save(sess, '/home/manh/Desktop/model/final_model.ckpt')
            # break
            # break
            i_ep += 1
            if using_adaptive_noise:
                s_batch_update, _, _, _, _ = replay_buffer.get_batch()
                s_batch_update = np.reshape(s_batch_update, (-1,state_size))
                action_1 = actor.predict(s_batch_update)
                action_2 = actor.predict_pertubed_network(s_batch)
                distance = np.sqrt(np.mean(np.square(action_1 - action_2)))
                adaptive_noise.adapt(distance)
            # print("achieve the goal")
            if i_ep % 500 == 0:
                saver.save(sess, '/home/manh/Desktop/model2/testtttt2/checkpoint_model.ckpt', i_ep)
            # if step_counter%10000:
            #     sigma = noise.get_sigma()*0.99
            #     sigma = max(sigma, 0.002)
            #     noise.set_sigma(sigma)
            if step_counter > 1020000:
                break
        # print("achieve the goal")
        saver.save(sess, '/home/manh/Desktop/model2/testtttt2/final_model.ckpt')


# load the ckpt model
def load_model(file_path, sess):
    with tf.Session() as sess:
        loader = tf.train.Saver()
        loader.restore(sess, file_path)


def perform(file_path):
    tf.reset_default_graph()
    # inference_graph = tf.get_default_graph()
    with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())
        meta_path = '/home/manh/Desktop/model2/test/checkpoint_model.ckpt8000.meta'
        actor = Actor(sess=sess, init=False)
        saver = tf.train.Saver()
        # saver.restore(sess, '/home/manh/Desktop/model2/testtttt/checkpoint_model.ckpt-70')
        saver.restore(sess, '/home/manh/Desktop/model2/testtttt2/checkpoint_model.ckpt-500')
        # actor.update_target_network_2()
        # aa = tf.train.get_checkpoint_state('/home/manh/Desktop/model2/test/')
        # print(aa)
        # print(os.path.basename(aa.model_checkpoint_path))
        # saver = tf.train.import_meta_graph(meta_path)
        # saver.restore(sess, tf.train.latest_checkpoint('/home/manh/Desktop/model2/test/'))
        graph = tf.get_default_graph()
        bias = graph.get_tensor_by_name('policy_estimator/dense_2/bias:0')
        #
        # # bias = inference_graph.get_tensor_by_name('policy_estimator/dense_2/bias:0')
        # print(sess.run(bias))
        # tf.global_variables_initializer().run()
        print(sess.run(bias))

        # while True:
        #     state = env.reset()
        #
        #     for t in itertools.count():
        #         action = actor.predict_target(state)
        #         next_state, reward, done, _ = env.step(action)
        #         state = next_state
        #         if done:
        #             break


if __name__ == '__main__':
    tf.reset_default_graph()

    alpha = 1.0
    epsilon = 0.9
    gamma = 0.7
    epsilon_discount = 0.99
    nepisodes = 500
    nstep = 0

    running_steps = 0.1
    wait_time = 0.2
    #
    rospy.init_node('example_a2c', anonymous=True, log_level=rospy.WARN)
    set_param(rospy)
    rospack = rospkg.RosPack()
    pkg_path = rospack.get_path('turtle2_openai_ros_example')
    outdir = pkg_path + '/training_result'
    env = gym.make('MyTurtleBot2Maze-v0')
    print (env.action_space)
    # date = datetime.datetime.now().date()
    # hour = datetime.datetime.now().hour
    # minute = datetime.datetime.now().minute
    # sec = datetime.datetime.now().second
    # file_path = '/home/manh/Desktop/model/my_final_model.ckpt'
    # rospy.loginfo('Gym environment done')
    # #
    # parse = argparse.ArgumentParser(description='provide arguments for DDPG agent')
    # parse.add_argument('--summary_dir', default='./summary'+
    #                                                 '-'+str(date)+'-'+str(hour)+'.'+str(minute)+'.'+str(sec))
    # parse.add_argument('--minibatch_size', default= 40)
    # parse.add_argument('--max_episode', default=100)
    #
    # args = vars(parse.parse_args())
    # # actor = Actor(sess=sess, init=True)
    # # num_actor_var = actor.get_num_trainable_vars()
    # # critic = Critic(sess=sess, num_trainable_vars=num_actor_var, init=True)
    # utilizes(args=args, env=env, file_path=file_path)

    ##############################################################################
    # file_path = '/home/manh/Desktop/model2/test/checkpoint_model.ckpt4000'  #
    # perform(file_path)  #
##################################################################################
