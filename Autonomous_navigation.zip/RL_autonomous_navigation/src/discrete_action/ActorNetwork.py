import tensorflow as tf
import numpy as np
import math
import keras.backend as k
from math import pi
import tflearn

SEED = 100


class Actor(object):
    def __init__(self, sess, init,learning_rate=1e-03, name_scope='policy_estimator', state_size=20, tau=0.001):
        tf.random.set_random_seed(SEED)
        with tf.variable_scope(name_scope):
            self.sess = sess
            self.tau = tau
            self.learning_rate = learning_rate
            self.state_size = state_size
            k.set_session(sess)
            self.s_dim = 12
            self.batch_size = 40
            self.action_size =1
            self.init_var = init
            # self.state = tf.placeholder(dtype=tf.float32, shape=[None, 36])

            #create the actor_model
            self.inputs, self.network_out = self.create_network()
            # self.network_out[0][:] = tf.clip_by_value(self.network_out[0][:],0, 0.3)
            self.weights = tf.trainable_variables()
            # print(len(tf.trainable_variables()))
            # print(self.weights)

            #create the actor target model
            self.target_inputs, self.target_network_out = self.create_network()
            # print(len(tf.trainable_variables()[len(self.weights):]))
            self.target_weights = tf.trainable_variables()[len(self.weights):]

            #create pertubed network
            self.pertubed_inputs, self.pertuberd_network_out = self.create_network()
            self.param_numb = len(self.weights) + len(self.target_weights)
            self.pertubed_weights = tf.trainable_variables()[len(self.weights) + len(self.target_weights):]


            # self.update_pertubed = [tf.assign(self.pertubed_weights[i], self.weights[i]) for i in range(10)]

            #update the target network
            self.update = \
                [self.target_weights[i].assign(tf.multiply(self.weights[i], self.tau) +
                                            tf.multiply(self.target_weights[i], 1 - self.tau))
                 for i in range(len(self.target_weights))]

            self.update_2 =  \
                [self.target_weights[i].assign(self.weights[i])
                 for i in range(len(self.target_weights))]

            self.update_3 = \
                [tf.assign(self.pertubed_weights[i], self.weights[i])
                 for i in range(len(self.weights))]

            self.standard_deviation = tf.placeholder(name='stddev', dtype=tf.float32, shape=())
            self.pertub_ops = [tf.assign(self.pertubed_weights[i], self.pertubed_weights[i]+
                                tf.random_normal(mean=0, shape=tf.shape(self.pertubed_weights[i]), stddev=self.standard_deviation))
                      for i in range(len(self.pertubed_weights))]

            self.action_grad = tf.placeholder(name='action_grad', dtype=tf.float32, shape=(None,self.action_size))
            self.param_grad = tf.gradients(self.network_out, self.weights, -self.action_grad)
            self.actor_gradients = list(map(lambda x: tf.div(x, self.batch_size), self.param_grad))
            grads = zip(self.actor_gradients, self.weights)

            self.optimize = tf.train.AdamOptimizer(self.learning_rate).apply_gradients(grads)
            # tf.train.AdamOptimizer().
            self.num_trainable_var = len(self.weights) + len(self.target_weights) + len(self.pertubed_weights)

            if self.init_var:
                self.sess.run(tf.global_variables_initializer())


    def create_network(self):
        # num_unit = 10
        inputs = tf.placeholder(dtype=tf.float32, shape=[None, self.s_dim])
        layer_1 = tf.layers.dense(
            inputs=inputs,
            units=400,
            activation=tf.nn.elu,
            # kernel_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None),
            # bias_initializer=tf.keras.initializers.RandomUniform(minval=--0.003, maxval=0.003, seed=None)
            kernel_initializer = tf.keras.initializers.he_uniform(),
            bias_initializer = tf.keras.initializers.he_uniform()
        )
        normalize = tflearn.layers.normalization.batch_normalization(layer_1)
        # dropout_layer_1 = tf.layers.dropout(layer_1, rate=0.5)
        layer_2 = tf.layers.dense(
            inputs= normalize,
            units= 300,
            activation=tf.nn.elu,
            # kernel_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None),
            # bias_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None)
            kernel_initializer=tf.keras.initializers.he_uniform(),
            bias_initializer=tf.keras.initializers.he_uniform()
        )
        # normalize_1 = tflearn.layers.normalization.batch_normalization(layer_2)
        # linear_velocity = tf.layers.dense(
        #     inputs= normalize_1,
        #     units=1,
        #     activation=tf.nn.sigmoid,
        #     kernel_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None),
        #     bias_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None)
        #
        # )
        angular_velocity = tf.layers.dense(
            inputs= layer_2,
            units=1,
            activation=tf.nn.tanh,
            kernel_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None),
            bias_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None))
        # output = tf.layers.dense(normalize_1,
        #                          2,
        #                          activation=tf.nn.tanh,
        #                          kernel_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None),
        #                          bias_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None)
        #                          # kernel_initializer=tf.keras.initializers.he_uniform(),
        #                          # bias_initializer=tf.keras.initializers.he_uniform()
        #                          )
        # output = tf.keras.layers.concatenate([linear_velocity,angular_velocity], axis=-1)
        # output = tf.multiply(output, [0.3, 1])
        return inputs, angular_velocity

    def update_target_network(self):

        self.sess.run(self.update)

    def update_target_network_2(self):

        self.sess.run(self.update_2)

    def update_pertubed(self):
        # update_pertubed = [tf.assign(self.pertubed_weights[i], self.weights[i]) for i in
        #                         range(len(self.pertubed_weights))]
        self.sess.run(self.update_3)

    def pertub_param(self, stddev):

        # pertub_ops = [tf.assign(self.pertubed_weights[i], self.pertubed_weights[i]+
        #                         tf.random_normal(mean=0, shape=tf.shape(self.pertubed_weights[i]), stddev=stddev))
        #               for i in range(len(self.pertubed_weights))]
        self.sess.run(self.pertub_ops, feed_dict={self.standard_deviation: stddev})

    def train(self, states, action_grads):
        self.sess.run(self.optimize, feed_dict={
            self.inputs: states,
            self.action_grad: action_grads
        })

    def predict(self, states):
        result = self.sess.run(self.network_out, feed_dict={self.inputs: states})
        return result

    def predict_target(self, states):
        result = self.sess.run(self.target_network_out, feed_dict={self.target_inputs: states})
        return result

    def predict_pertubed_network(self, states):
        result = self.sess.run(self.pertuberd_network_out, feed_dict={self.pertubed_inputs: states})
        return result

    def get_num_trainable_vars(self):
        return self.num_trainable_var


