import sys
import os
sys.path.insert(0, os.path.dirname(__file__))
sys.path.append(os.path.realpath(os.getcwd()))

import tensorflow as tf

from collections import namedtuple
import numpy as np
import rospy
import gym
import rospkg
import argparse
from Configuration import my_turtlebot2_maze

SEED = 100

EpisodeStats = namedtuple("Stats", ['episode_length', 'episode_reward'])


class Actor(object):
    def __init__(self, sess, init, learning_rate=1e-02, name_scope='policy_estimator', state_size=20, tau=0.0001):
        tf.random.set_random_seed(SEED)
        with tf.variable_scope(name_scope):
            self.sess = sess
            self.tau = tau
            self.learning_rate = learning_rate
            self.state_size = state_size
            # k.set_session(sess)
            self.s_dim = 12
            self.action_dim = 5
            self.batch_size = 60
            self.init_var = init
            # declare the input variable
            self.chosen_action = tf.placeholder(dtype=tf.int32)
            self.target = tf.placeholder(dtype=tf.float32)

            # create the actor network
            self.state, self.output = self.create_network()
            self.output = tf.squeeze(self.output)
            self.chosen_action_probs = tf.gather(self.output, self.chosen_action)

            self.entropy = tf.reduce_sum(-tf.log(self.output))

            self.loss = -tf.log(self.chosen_action_probs) * self.target + 0.01*self.entropy

            # optimize the loss function
            self.optimize = tf.train.AdamOptimizer(learning_rate=0.01)
            self.train_op = self.optimize.minimize(self.loss)

            # self.param_grad = tf.gradients(self.network_out, self.weights, -self.action_grad)
            # # self.actor_gradients = list(map(lambda x: tf.div(x, self.batch_size), self.param_grad))
            # grads = zip(self.param_grad, self.weights)
            #
            # self.optimize = tf.train.AdamOptimizer(self.learning_rate).apply_gradients(grads)
            # self.num_trainable_var = len(self.weights) + len(self.target_weights)

            if self.init_var:
                self.sess.run(tf.global_variables_initializer())

    def create_network(self):
        state = tf.placeholder(dtype=tf.float32, shape=[None, self.s_dim])

        layer_1 = tf.layers.dense(
            inputs=state,
            units=256,
            activation=tf.nn.leaky_relu,
            kernel_initializer=tf.keras.initializers.zeros(),
            bias_initializer= tf.keras.initializers.zeros())
            # kernel_initializer=tf.keras.initializers.he_normal(),
            # bias_initializer=tf.keras.initializers.he_normal())
        layer_2 = tf.layers.dense(
            inputs=layer_1,
            units=256,
            activation=tf.nn.leaky_relu,
            kernel_initializer=tf.keras.initializers.zeros(),
            bias_initializer=tf.keras.initializers.zeros()
            # kernel_initializer=tf.keras.initializers.he_normal(),
            # bias_initializer=tf.keras.initializers.he_normal()
        )
        output = tf.layers.dense(
            inputs=layer_2,
            units=self.action_dim,
            activation=tf.nn.leaky_relu,
            kernel_initializer=tf.keras.initializers.zeros(),
            bias_initializer=tf.keras.initializers.zeros()
            # kernel_initializer=tf.keras.initializers.he_normal(),
            # bias_initializer=tf.keras.initializers.he_normal()
        )
        softmax = tf.nn.softmax(output)
        return state, softmax

    def train(self, states, chosen_action, target):
        loss,_ = self.sess.run([self.loss, self.train_op], feed_dict={
            self.state: states,
            self.chosen_action: chosen_action,
            self.target: target
        })
        return loss

    def predict(self, states):
        result = self.sess.run(self.output, feed_dict={self.state: states})
        return result

    # def get_num_trainable_vars(self):
    #     return self.num_trainable_var


#####################################################################################################################
###########################
#      Critic-network     #
###########################


class Critic(object):
    def __init__(self, sess, init, learning_rate=1e-04, scope_name='value_estimator',
                 num_actor_var=0, tau=0.0001,
                 gamma=0.99, ):
        tf.random.set_random_seed(SEED)
        with tf.variable_scope(scope_name):
            self.learning_rate = learning_rate
            self.tau = tau
            self.gamma = gamma
            self.sess = sess
            self.action_dim = 5
            self.s_dim = 12
            # self.num_trainable_vars = num_trainable_vars
            self.init_var = init

            # declare the input variable
            self.target = tf.placeholder(dtype=tf.float32)
            self.state, self.output = self.create_network()

            # train the critic neural network
            self.loss = tf.reduce_mean(tf.squared_difference(self.target, self.output))
            self.optimze = tf.train.AdamOptimizer(learning_rate=0.01)
            self.train_op = self.optimze.minimize(self.loss)
            if self.init_var:
                sess.run(tf.global_variables_initializer())

    def create_network(self):
        state = tf.placeholder(dtype=tf.float32, shape=[None, self.s_dim])
        layer_1 = tf.layers.dense(
            inputs=state,
            units=256,
            activation=tf.nn.leaky_relu,
            kernel_initializer=tf.keras.initializers.zeros(),
            bias_initializer=tf.keras.initializers.zeros()
            # kernel_initializer=tf.keras.initializers.he_normal(),
            # bias_initializer=tf.keras.initializers.he_normal()
        )
        layer_2 = tf.layers.dense(
            inputs=layer_1,
            units=256,
            activation=tf.nn.leaky_relu,
            kernel_initializer=tf.keras.initializers.zeros(),
            bias_initializer=tf.keras.initializers.zeros()
            # kernel_initializer=tf.keras.initializers.he_normal(),
            # bias_initializer=tf.keras.initializers.he_normal()
        )
        output = tf.layers.dense(
            inputs=layer_2,
            units=1,
            kernel_initializer=tf.keras.initializers.zeros(),
            bias_initializer=tf.keras.initializers.zeros()
            # kernel_initializer=tf.keras.initializers.he_normal(),
            # bias_initializer=tf.keras.initializers.he_normal()
        )
        return state, output

    def train(self, state, target):
        loss, _ = self.sess.run([self.loss, self.train_op], feed_dict={
            self.state: state,
            self.target: target
        })
        return loss

    def predict(self, states):
        result = self.sess.run(self.output, feed_dict={self.state: states})
        return result


def build_summaries():
    episode_reward = tf.Variable(0.)
    tf.summary.scalar('Reward', episode_reward)

    episode_critic_loss = tf.Variable(0.)
    tf.summary.scalar('Critic_loss', episode_critic_loss)

    episode_actor_loss = tf.Variable(0.)
    tf.summary.scalar('Actor_loss', episode_actor_loss)

    summary_vars = [episode_reward, episode_critic_loss, episode_actor_loss]
    summary_ops = tf.summary.merge_all()
    return summary_ops, summary_vars


###########################################################################################################################
######################## SOME HELPER FUNCTION ########################################################################
def sample_action(prob_dis):
    action = np.random.choice(a=np.arange(len(prob_dis)), p=prob_dis)
    return action


def a2c(actor, critic, env, args, discount_factor=0.99):
    with tf.Session() as sess:
        max_ep = 200
        max_step = 5
        epsilon_rand = 0.99
        epsilon_rand_discount = 0.0001

        summary_ops, summary_vars = build_summaries()
        sess.run(tf.global_variables_initializer())
        writer = tf.summary.FileWriter(args['summary_dir'], sess.graph)
        tf.get_default_graph().finalize()

        for i_ep in range(max_ep):
            ep_reward = 0
            ep_critic_loss = 0
            ep_actor_loss = 0
            episode = []
            state = env.reset()
            while True:
                # for i in range(max_step):
                action_prob_dist = actor.predict(state)
                print(action_prob_dist)
                action = sample_action(action_prob_dist)
                print(action)

                next_state, reward, done,_ = env.step(action)

                value_next = critic.predict(next_state)
                td_target = reward + value_next * discount_factor
                td_error = td_target - critic.predict(state)

                action = np.array(action)
                action = np.reshape(action, (-1,1))
                td_error = np.array(td_error)
                td_error = np.reshape(td_error, (-1,1))
                # critic.train_op(state, td_target)
                # actor.train_op(state, action, td_error)
                critic_l = critic.train(state, td_target)
                actor_l = actor.train(state, action, td_error)

                ep_reward += reward
                ep_critic_loss += critic_l
                ep_actor_loss += actor_l
                if done:
                    print('criticloss:'+str(critic_l))
                    print('actorloss:' + str(actor_l))
                    ep_actor_loss= float(actor_l)
                    summary_stats = sess.run(summary_ops, feed_dict={
                        summary_vars[0]: ep_reward,
                        summary_vars[1]: ep_critic_loss,
                        summary_vars[2]: ep_actor_loss
                    })
                    writer.add_summary(summary_stats, i_ep)
                    writer.flush()
                    print('| Reward: {:d} | Episode: {:d} | Critic_loss: {:.4f} | Actor_loss: {:.4f}' \
                          .format(int(ep_reward), i_ep, ep_critic_loss, ep_actor_loss))
                    break


def set_param(ros):
    ros.set_param("/turtlebot2/n_actions", 3)
    ros.set_param("/turtlebot2/alpha", alpha)
    ros.set_param("/turtlebot2/epsilon", epsilon)
    ros.set_param("/turtlebot2/gamma", gamma)
    ros.set_param("/turtlebot2/epsilon_discount", epsilon_discount)
    ros.set_param("/turtlebot2/nepisodes", nepisodes)
    ros.set_param("/turtlebot2/nsteps", nstep)
    ros.set_param("/turtlebot2/running_step", running_steps)
    ros.set_param("/turtlebot2/linear_forward_speed", 0.5)
    ros.set_param("/turtlebot2/linear_turn_speed", 0.1)
    ros.set_param("/turtlebot2/angular_speed", 0.3)
    ros.set_param("/turtlebot2/init_linear_forward_speed", 0.0)
    ros.set_param("/turtlebot2/init_linear_turn_speed", 0.0)
    ros.set_param("/turtlebot2/new_ranges", 5)
    ros.set_param("/turtlebot2/min_range", 0.5)
    ros.set_param("/turtlebot2/max_laser_value", 6.0)
    ros.set_param("/turtlebot2/min_laser_value", 0.0)

    ros.set_param("/turtlebot2/number_of_sectors", 3)
    ros.set_param("/turtlebot2/min_range", 0.5)
    ros.set_param("/turtlebot2/middle_range", 1.0)
    ros.set_param("/turtlebot2/danger_laser_value", 0.2)
    ros.set_param("/turtlebot2/middle_laser_value", 1)
    ros.set_param("/turtlebot2/safe_laser_value", 0)
    ros.set_param("/turtlebot2/forwards_reward", 5)
    ros.set_param("/turtlebot2/turn_reward", 1)
    ros.set_param("/turtlebot2/end_episode_points", 200)


def set_environment_param():
    parse = argparse.ArgumentParser(description='provide arguments for DDPG agent')
    parse.add_argument('--summary_dir', default='./summary')
    parse.add_argument('--minibatch_size', default=30)
    parse.add_argument('--max_episode', default=100)
    return parse


if __name__ == '__main__':
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        sess.run(tf.global_variables_initializer())
        alpha = 1.0
        epsilon = 0.9
        gamma = 0.7
        epsilon_discount = 0.999
        nepisodes = 500
        nstep = 0

        running_steps = 0.1
        wait_time = 0.1
        rospy.init_node('example_a2c', anonymous=True, log_level=rospy.WARN)
        set_param(rospy)
        rospack = rospkg.RosPack()
        pkg_path = rospack.get_path('turtle2_openai_ros_example')
        # outdir = pkg_path + '/training_result'

        env = gym.make('MyTurtleBot2Maze-v0')
        rospy.loginfo('Gym environment done')

        parse = argparse.ArgumentParser(description='provide arguments for DDPG agent')
        parse.add_argument('--summary_dir', default='./summary')
        parse.add_argument('--minibatch_size', default=30)
        parse.add_argument('--max_episode', default=100)

        args = vars(parse.parse_args())
        actor = Actor(sess=sess, init=True)
        # num_actor_var = actor.get_trainable_var()
        critic = Critic(sess=sess, init=True)

        a2c(actor=actor, critic=critic, args=args, env=env)
        # init = tf.global_variables_initializer()

# for t in range(max_step):
#     acton_prob_dis = actor.predict(state)
#     action = sample_action(acton_prob_dis)
#     v_value = critic.predict(state)
#
#     next_state, reward, done = env.step(action)
#
#     m_states.append(state)
#     m_actions.append(action)
#     m_rewards.append(reward)
#     m_dones.append(done)
#     m_v_values.append(v_value)
#     state = next_state
#     if done:
#         break
# m_actions = np.asarray(m_actions, dtype=np.int16)
# m_states = np.asarray(m_states, dtype=np.float32)
# m_rewards = np.asarray(m_rewards, dtype=np.float32)
# m_v_values = np.asarray(m_v_values, dtype=np.float32)
# m_dones = np.asarray(m_dones, dtype=np.bool)
# last_values = critic.predict(state)
#
# m_returns = np.zeros_like(m_rewards)
# m_advantages = np.zeros_like(m_rewards)
# lastgaelam = 0
# for tt in reversed(range(max_step)):
#     if t == max_step - 1:
#         nextnonterminal = 1 - done
#         next_value = last
