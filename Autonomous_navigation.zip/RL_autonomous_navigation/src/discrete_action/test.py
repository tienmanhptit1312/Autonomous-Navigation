from mpi4py import MPI
# from baselines.common import set_global_seeds
# from baselines import bench
import os.path as osp
# from baselines import logger
# from baselines.common.atari_wrappers import make_atari, wrap_deepmind
# from baselines.common.cmd_util import atari_arg_parser
import gym
import random
import numpy as np
import rospy
import rospkg
from Configuration import my_turtlebot2_maze
from src.discrete_action.ackt.acktr import learn
import tensorflow as tf
from ackt.acktr import Model
from src.discrete_action.ackt.Helper_function import build_policy


def set_global_seeds(i):
    # try:
    #     import MPI
    #     rank = MPI.COMM_WORLD.Get_rank()
    # except ImportError:
    #     rank = 0

    myseed = i + 1000 * 1
    try:
        import tensorflow as tf
        tf.set_random_seed(myseed)
    except ImportError:
        pass
    np.random.seed(myseed)
    random.seed(myseed)


# def train(env, num_timesteps, seed):
#     from RL_autonomous_navigation.src.discrete_action.ppo import pposgd_simple, mlp_policy
#     import RL_autonomous_navigation.src.discrete_action.ackt.tf_util as U
#     rank = MPI.COMM_WORLD.Get_rank()
#     sess = U.single_threaded_session()
#     sess.__enter__()
#     workerseed = seed + 10000 * MPI.COMM_WORLD.Get_rank() if seed is not None else None
#     set_global_seeds(workerseed)
#
#     # env = make_atari(env_id)
#     def policy_fn(name, ob_space, ac_space, h, unit):  # pylint: disable=W0613
#         return mlp_policy.MlpPolicy(name=name, ob_space=ob_space, ac_space=ac_space, hid_size=h, num_hid_layers=unit)
#
#     # policy = policy_fn()
#     pposgd_simple.learn(env, policy_fn,
#                         max_timesteps=int(num_timesteps * 1.1),
#                         timesteps_per_actorbatch=20,
#                         clip_param=0.2, entcoeff=0.01,
#                         optim_epochs=4, optim_stepsize=1e-3, optim_batchsize=5,
#                         gamma=0.99, lam=0.95,
#                         schedule='linear'
#                         )
#     env.close()


def set_param(ros):
    ros.set_param("/turtlebot2/n_actions", 5)
    ros.set_param("/turtlebot2/alpha", alpha)
    ros.set_param("/turtlebot2/epsilon", epsilon)
    ros.set_param("/turtlebot2/gamma", gamma)
    ros.set_param("/turtlebot2/epsilon_discount", epsilon_discount)
    ros.set_param("/turtlebot2/nepisodes", nepisodes)
    ros.set_param("/turtlebot2/nsteps", nstep)
    ros.set_param("/turtlebot2/running_step", running_steps)
    ros.set_param("/turtlebot2/linear_forward_speed", 0.5)
    ros.set_param("/turtlebot2/linear_turn_speed", 0.1)
    ros.set_param("/turtlebot2/angular_speed", 0.3)
    ros.set_param("/turtlebot2/init_linear_forward_speed", 0.0)
    ros.set_param("/turtlebot2/init_linear_turn_speed", 0.0)
    ros.set_param("/turtlebot2/new_ranges", 5)
    ros.set_param("/turtlebot2/min_range", 0.5)
    ros.set_param("/turtlebot2/max_laser_value", 6.0)
    ros.set_param("/turtlebot2/min_laser_value", 0.0)

    ros.set_param("/turtlebot2/number_of_sectors", 3)
    ros.set_param("/turtlebot2/min_range", 0.5)
    ros.set_param("/turtlebot2/middle_range", 1.0)
    ros.set_param("/turtlebot2/danger_laser_value", 2)
    ros.set_param("/turtlebot2/middle_laser_value", 1)
    ros.set_param("/turtlebot2/safe_laser_value", 0)
    ros.set_param("/turtlebot2/forwards_reward", 5)
    ros.set_param("/turtlebot2/turn_reward", 1)
    ros.set_param("/turtlebot2/end_episode_points", 200)


# def main():

if __name__ == '__main__':
    # args = atari_arg_parser().parse_args()
    alpha = 1.0
    epsilon = 0.9
    gamma = 0.7
    epsilon_discount = 0.99
    nepisodes = 500
    nstep = 0

    running_steps = 0.1
    wait_time = 0.2

    #
    rospy.init_node('example_a2c', anonymous=True, log_level=rospy.WARN)
    set_param(rospy)
    # rospack = rospkg.RosPack()
    # pkg_path = rospack.get_path('turtle2_openai_ros_example')
    # outdir = pkg_path + '/training_result'
    # policy = 0
    env = gym.make('MyTurtleBot2Maze-v0')

    ##################33-------------------###########33
    nenvs = 1
    ob_space = env.observation_space
    ac_space = env.action_space
    total_timesteps = int(1e6)
    gamma = 0.99
    log_interval = 10
    nprocs = 32
    nsteps = 5,
    ent_coef = 0.01
    vf_coef = 0.5
    vf_fisher_coef = 1.0
    lr = 0.25
    max_grad_norm = 0.5,
    kfac_clip = 0.001
    save_interval = 10
    lrschedule = 'linear'
    load_path = None
    is_async = True
    ###########################----------------------------------
    # model = learn(env=env, seed=1234, network='mlp')
    policy = build_policy(env, policy_network='mlp')
    model =  Model(policy, ob_space, ac_space, nenvs, total_timesteps, nprocs=nprocs, nsteps
    =nsteps, ent_coef=ent_coef, vf_coef=vf_coef, vf_fisher_coef=
                               vf_fisher_coef, lr=lr, max_grad_norm=max_grad_norm, kfac_clip=kfac_clip,
                               lrschedule=lrschedule, is_async=is_async)
    graph = tf.get_default_graph()
    sess = tf.get_default_session()
    model_path= '/home/manhlt/Desktop/checkpoint259682'
    model.load(model_path)
    for i in range(10):
        obs = env.reset()
        state = model.initial_state
        done = False
        while True:
            actions, values, states, _, _ = model.train_model.step(obs, S=state, M=done)
            next_obs, reward, next_done, _ = env.step(actions)
            print(reward)
            obs= next_obs
            done = next_done
            if done:
                break
    # save.restore(sess, '/home/manh/Desktop/autonomous_model/checkpoint00001')
    print(sess.run('acktr_model/pi/mlp_fc0/w:0'))
