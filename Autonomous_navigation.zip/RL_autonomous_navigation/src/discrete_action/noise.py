import numpy as np
import numpy.random as nr
import tensorflow as tf

class OUNoise:
    """docstring for OUNoise"""
    def __init__(self,action_dimension,mu=0, theta=0.15, sigma=0.2):
        self.action_dimension = action_dimension
        self.mu = mu
        self.theta = theta
        self.sigma = sigma
        self.state = np.ones(self.action_dimension) * self.mu
        self.reset()

    def reset(self):
        self.state = np.ones(self.action_dimension) * self.mu

    def noise(self):
        x = self.state
        dx = self.theta * (self.mu - x) + self.sigma * nr.randn(len(x))
        self.state = x + dx
        return self.state
    def get_sigma(self):
        return self.sigma

    def set_sigma(self, sigma):
        self.sigma = sigma

class OrnsteinUhlenbeckActionNoise:
    def __init__(self, mu, sigma=0.2, theta=.15, dt=1e-2, x0=None):
        self.theta = theta
        self.mu = mu
        self.sigma = sigma
        self.dt = dt
        self.x0 = x0
        self.reset()

    def __call__(self):
        x = self.x_prev + self.theta * (self.mu - self.x_prev) * self.dt + \
                self.sigma * np.sqrt(self.dt) * np.random.normal(size=self.mu.shape)
        self.x_prev = x
        return x

    def reset(self):
        self.x_prev = self.x0 if self.x0 is not None else np.zeros_like(self.mu)

    def __repr__(self):
        return 'OrnsteinUhlenbeckActionNoise(mu={}, sigma={})'.format(self.mu, self.sigma)
    def get_sigma(self):
        return self.sigma
    def set_sigma(self, sigma):
        self.sigma = sigma

class AdaptiveParameterNoise(object):
    def __init__(self, initial_stddev = 0.1, desired_action_stddev=0.1, adoption_coefficient=1.01):
        self.initial_stddev = initial_stddev
        self.desired_action_stddev = desired_action_stddev
        self.adoption_coefficient = adoption_coefficient

        self.current_stddev = initial_stddev

    def adapt(self, distance):
        if distance > self.desired_action_stddev:
            self.current_stddev/= self.adoption_coefficient
        else:
            self.current_stddev*= self.adoption_coefficient

    def __repr__(self):
        fmt = 'AdaptiveParamNoiseSpec(initial_stddev={}, desired_action_stddev={}, adoption_coefficient={})'
        return fmt.format(self.initial_stddev, self.desired_action_stddev, self.adoption_coefficient)

#######################################################################################################################
#   Noise network setup
def f(x):
    return tf.multiply(tf.sign(x), tf.pow(tf.abs(x), 0.5))

def sample_noise(shape):
    noise = tf.random_normal(shape)
    return noise

def noise_dense(input_layer, units, name, bias=True, activation_func=tf.identity):

    #initialize mu and sigma
    mu_init = tf.random_uniform(minval=-1*1/np.power(input_layer.get_shape().as_list()[1], 0.5),
                                maxval=1*1/np.power(input_layer.get_shape().as_list()[1], 0.5))
    sigma_init = tf.constant_initializer(0.4/np.power(input_layer.get_shape().aslist()[1], 0.5))

    #sample noise from gaussian
    p= sample_noise([input_layer.get_shape().as_list()[1], 1])
    q= sample_noise([1, units])
    f_p = f(p); f_q= f(q)
    w_epsilon= f_p*f_q; b_epsilon = tf.squeeze(f_q)

    #w= w_mu + w_sigma*w_epsilon
    w_mu = tf.get_variable(name=name+'/w_mu', shape=(input_layer.get_shape().as_list()[1], units), initializer=mu_init)
    w_sigma = tf.get_variable(name=name+'/w_sigma', shape=(input_layer.get_shape().as_list()[1], units), initializer=sigma_init)
    w = w_mu + tf.multiply(w_sigma, w_epsilon)
    result = tf.matmul(input_layer, w)

    if bias:
        b_mu = tf.get_variable(name= name+'/b_mu', shape=[units], initializer=mu_init)
        b_sigma = tf.get_variable(name=name+ '/b_sigma', shape=[units], initializer=sigma_init)
        b = b_mu + tf.multiply(b_sigma, b_epsilon)
        result += b
        return activation_func(result)
    else:
        return activation_func(result)




if __name__ == '__main__':
    ou = OUNoise(1)
    aa = np.random.normal(size=2)
    print(aa)
    aa1= aa+1
    print(aa1)
    # ou.noise()
    # a = nr.randn(1)
    # print(ou.state)
    # states = []
    # for i in range(1000):
    #     states.append(ou.noise())
    # import matplotlib.pyplot as plt
    #
    # plt.plot(states)
    # plt.show()


