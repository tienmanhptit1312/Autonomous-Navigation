import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
sys.path.append(os.path.realpath(os.getcwd()))
import rospy
import rospkg
import gym
from src.discrete_action.a2c.a2c import learn
from Configuration import my_turtlebot2_maze




def set_param(ros):
    ros.set_param("/turtlebot2/n_actions", 5)
    ros.set_param("/turtlebot2/alpha", alpha)
    ros.set_param("/turtlebot2/epsilon", epsilon)
    ros.set_param("/turtlebot2/gamma", gamma)
    ros.set_param("/turtlebot2/epsilon_discount", epsilon_discount)
    ros.set_param("/turtlebot2/nepisodes", nepisodes)
    ros.set_param("/turtlebot2/nsteps", nstep)
    ros.set_param("/turtlebot2/running_step", running_steps)
    ros.set_param("/turtlebot2/linear_forward_speed", 0.5)
    ros.set_param("/turtlebot2/linear_turn_speed", 0.1)
    ros.set_param("/turtlebot2/angular_speed", 0.3)
    ros.set_param("/turtlebot2/init_linear_forward_speed", 0.0)
    ros.set_param("/turtlebot2/init_linear_turn_speed", 0.0)
    ros.set_param("/turtlebot2/new_ranges", 5)
    ros.set_param("/turtlebot2/min_range", 0.5)
    ros.set_param("/turtlebot2/max_laser_value", 6.0)
    ros.set_param("/turtlebot2/min_laser_value", 0.0)

    ros.set_param("/turtlebot2/number_of_sectors", 3)
    ros.set_param("/turtlebot2/min_range", 0.5)
    ros.set_param("/turtlebot2/middle_range", 1.0)
    ros.set_param("/turtlebot2/danger_laser_value", 2)
    ros.set_param("/turtlebot2/middle_laser_value", 1)
    ros.set_param("/turtlebot2/safe_laser_value", 0)
    ros.set_param("/turtlebot2/forwards_reward", 5)
    ros.set_param("/turtlebot2/turn_reward", 1)
    ros.set_param("/turtlebot2/end_episode_points", 200)


if __name__=='__main__':
    alpha = 1.0
    epsilon = 0.9
    gamma = 0.7
    epsilon_discount = 0.99
    nepisodes = 500
    nstep = 0

    running_steps = 0.1
    wait_time = 0.2
    #
    rospy.init_node('example_a2c', anonymous=True, log_level=rospy.WARN)
    set_param(rospy)
    rospack = rospkg.RosPack()
    pkg_path = rospack.get_path('turtle2_openai_ros_example')
    outdir = pkg_path + '/training_result'
    policy = 0
    env = gym.make('MyTurtleBot2Maze-v0')
    print(env.observation_space)
    # model = Model(policy=policy, ob_space=12, ac_space=5)
    learn(env=env, seed=1234, network='mlp')