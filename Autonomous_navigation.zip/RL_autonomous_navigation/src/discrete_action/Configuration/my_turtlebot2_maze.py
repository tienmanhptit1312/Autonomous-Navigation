import rospy
import numpy
import time
from gym import spaces
import turtlebot2_env
from gym.envs.registration import register
import numpy as np
import math
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist, Point, Pose
from math import  pi
from tf.transformations import euler_from_quaternion
from respawnGoal import Respawn
from std_msgs.msg import Float32
from std_msgs.msg import String
import math
timestep_limit_per_episode = 10000 # Can be any Value

register(
        id='MyTurtleBot2Maze-v0',
        entry_point='Configuration.my_turtlebot2_maze:MyTurtleBot2MazeEnv',
        timestep_limit=timestep_limit_per_episode,
    )
HIGH = 1
LOW = -1
class MyTurtleBot2MazeEnv(turtlebot2_env.TurtleBot2Env):
    def __init__(self):
        """
        This Task Env is designed for having the TurtleBot2 in some kind of maze.
        It will learn how to move around the maze without crashing.
        """

        # Only variable needed to be set here
        # number_actions = rospy.get_param('/turtlebot2/n_actions')
        self.action_space = spaces.Discrete(5)
        self.observation_space = spaces.Box(low=-20,high=20, shape=[12])
        # self.observation_space =spaces.

        #change action space to continous

        # self.action_space = spaces.Box(low=LOW, high=HIGH, shape=[2])
        
        # We set the reward range, which is not compulsory but here we do it.
        self.reward_range = (-numpy.inf, numpy.inf)

        
        # self.pub_heading = rospy.Publisher('heading', Float32,queue_size=1)
        # self.pub_heading_goal = rospy.Publisher('angular_goal', Float32, queue_size=1)
        # self.pub_heading_robot = rospy.Publisher('angular_robot', Float32, queue_size=1)
        self.pub_string_heading = rospy.Publisher('heading_data', String, queue_size=5)
        self.pub_dis = rospy.Publisher('distance', Float32, queue_size=1)
        #number_observations = rospy.get_param('/turtlebot2/n_observations')
        """
        We set the Observation space for the 6 observations
        cube_observations = [
            round(current_disk_roll_vel, 0),
            round(y_distance, 1),
            round(roll, 1),
            round(pitch, 1),
            round(y_linear_speed,1),
            round(yaw, 1),
        ]
        """

        # Actions and Observations
        self.linear_forward_speed = rospy.get_param('/turtlebot2/linear_forward_speed')
        self.linear_turn_speed = rospy.get_param('/turtlebot2/linear_turn_speed')
        self.angular_speed = rospy.get_param('/turtlebot2/angular_speed')
        self.init_linear_forward_speed = rospy.get_param('/turtlebot2/init_linear_forward_speed')
        self.init_linear_turn_speed = rospy.get_param('/turtlebot2/init_linear_turn_speed')
        
        self.number_of_sectors = rospy.get_param('/turtlebot2/number_of_sectors')
        self.min_range = rospy.get_param('/turtlebot2/min_range')
        self.middle_range = rospy.get_param('/turtlebot2/middle_range')
        
        # self.danger_laser_value = rospy.get_param('/turtlebot2/danger_laser_value')
        self.danger_laser_value = 0.22
        self.middle_laser_value = rospy.get_param('/turtlebot2/middle_laser_value')
        self.safe_laser_value = rospy.get_param('/turtlebot2/safe_laser_value')
        self.last_action=None
        
        
        # We create two arrays based on the binary values that will be assigned
        # In the discretization method.
        high = numpy.full((self.number_of_sectors), self.danger_laser_value)
        low = numpy.full((self.number_of_sectors), self.safe_laser_value)
        
        # We only use two integers
        self.observation_space = spaces.Box(low, high)
        
        rospy.logdebug("ACTION SPACES TYPE===>"+str(self.action_space))
        rospy.logdebug("OBSERVATION SPACES TYPE===>"+str(self.observation_space))
        
        # Rewards
        self.forwards_reward = rospy.get_param("/turtlebot2/forwards_reward")
        self.turn_reward = rospy.get_param("/turtlebot2/turn_reward")
        self.end_episode_points = rospy.get_param("/turtlebot2/end_episode_points")

        self.cumulated_steps = 0.0

        #adding code to achieve the state
        # self.goal_x = 0
        # self.goal_y = 0
        # self.respawn_goal = Respawn()
        # self.goal_x, self.goal_y = self.respawn_goal.getPosition()
        self.heading = 0
        self.position = Pose()
        self.sub_odom = rospy.Subscriber('odom', Odometry, self.getOdom)

        # Here we will add any init functions prior to starting the MyRobotEnv
        super(MyTurtleBot2MazeEnv, self).__init__()


##########################################################################3##########################
    def getOdom(self, odom):
        self.position = odom.pose.pose.position
        orientation = odom.pose.pose.orientation
        orientation_list = [orientation.x, orientation.y, orientation.z, orientation.w]
        _, _, yaw = euler_from_quaternion(orientation_list)

        goal_angle = math.atan2(self.goal_y - self.position.y, self.goal_x - self.position.x)

        heading = goal_angle - yaw
        if heading > pi:
            heading -= 2 * pi

        elif heading < -pi:
            heading += 2 * pi
        heading = round(heading,3)
        # self.pub_heading.publish(heading)
        data = 'robot head:'+str(yaw)+ '--goal_angle:'+str(goal_angle)+'--heading:'+str(heading)
        self.pub_string_heading.publish(data)
        self.heading = heading

    def getGoalDistace(self):
        goal_distance = round(math.hypot(self.goal_x - self.position.x, self.goal_y - self.position.y), 2)

        return goal_distance
#####################################################################################################
    def _set_init_pose(self):
        """Sets the Robot in its init pose
        """
        
        self.move_base( self.init_linear_forward_speed,
                        self.init_linear_turn_speed,
                        epsilon=0.05,
                        update_rate=10)
        
        

        return True


    def _init_env_variables(self):
        """
        Inits variables needed to be initialised each time we reset at the start
        of an episode.
        :return:
        """
        # For Info Purposes
        self.cumulated_reward = 0.0
        
        # This is necessary to give the laser sensors to refresh in the new reseted position.
        # rospy.logwarn("Waiting...")
        time.sleep(0.5)
        # rospy.logwarn("END Waiting...")


    def _set_action(self, action):
        """
        This set action will Set the linear and angular speed of the turtlebot2
        based on the action number given.
        :param action: The action integer that set s what movement to do next.
        """
        
        rospy.logdebug("Start Set Action ==>"+str(action))
        # We convert the actions to speed movements to send to the parent class CubeSingleDiskEnv
        if action == 2: #FORWARD
            # linear_speed = self.linear_forward_speed
            angular_speed = 0.0
            self.last_action = "FORWARDS"
        elif action <2: #LEFT
            # linear_speed = self.linear_turn_speed
            angular_speed = (action - 2)*pi/8
            self.last_action = "TURN_LEFT"
        elif action >2: #RIGHT
            # linear_speed = self.linear_turn_speed
            angular_speed = (action - 2)*pi/8
            self.last_action = "TURN_RIGHT"

        linear_speed = 0.2
        # angular_speed = action
        self.last_action = action
        self.last_distant = self.getGoalDistace()
        
        # We tell TurtleBot2 the linear and angular speed to set to execute
        self.move_base(linear_speed, angular_speed, epsilon=0.05, update_rate=10)
        
        rospy.logdebug("END Set Action ==>"+str(action))

    def _get_obs(self):
        """
        Here we define what sensor data defines our robots observations
        To know which Variables we have acces to, we need to read the
        TurtleBot2Env API DOCS
        :return:
        """
        rospy.logwarn("the last action" + str(self.get_last_action()))
        # rospy.logdebug("Start Get Observation ==>")
        # We get the laser scan data
        laser_scan = self.get_laser_scan()
        observation = laser_scan.ranges
        # laser_scan = laser_scan[8]
        observation = np.array(observation)
        number_scan = len(observation)
        # observation = np.reshape(observation, (1, 360))
        result = [min(3.5, observation[i]) for i in range(number_scan)]
        result = np.reshape(result, (1, number_scan))
        heading = self.heading
        heading = round(heading, 3)

        current_distant = round(math.hypot(self.goal_x-self.position.x, self.goal_y-self.position.y),2)
        current_distant = round(current_distant, 3)
        self.pub_dis.publish(current_distant)

        result = np.concatenate((result, np.array([[heading, current_distant]])), axis=1)
        return result
        

    def _is_done(self, observations):

        check_obs = np.reshape(observations[0][0:10],(10))
        episode_done = not (self.check_laser_sector_readings_safe(check_obs))
        
        
        if episode_done:
            rospy.logerr("TurtleBot2 is Too Close to wall==>")
            # self.goal_x, self.goal_y = self.respawn_goal.getPosition(True, delete=True)

        else:
            rospy.logerr("TurtleBot2 is Ok ==>")

        return episode_done

    def _compute_reward(self, observations, done):
        distance = self.last_distant - observations[0][11]

        if not done:
            if observations[0][11] < 0.2:
                rospy.logerr("Turtlebot3 achieve a goal")
                reward = 50
                self.goal_x, self.goal_y = self.respawn_goal.getPosition(True, True)
            elif distance < 0:
                reward = - math.pow(2, distance)
            elif self.last_distant == observations[0][11]:
                reward = 0
            else:
                # abs_action = math.fabs(self.last_action)
                # abs_heading = math.fabs(observations[0][10])
                # reward = 5/(math.pow(math.e, abs_heading)) + 20*((self.last_distant-observations[0][37])/observations[0][37])
                # reward = 1/(math.pow(math.e, abs_heading)) + 5 * ((self.last_distant - observations[0][11]) / 0.066)
                # reward =  5 * ((self.last_distant - observations[0][19]) / 0.066)
                # reward = 1
                reward = math.pow(2, distance)
            # if self.last_action == "FORWARDS":
            #     reward = self.forwards_reward
            # elif self.last_action == "BACKWARDS":
            #     reward = -1*self.forwards_reward
            # else:
            #     reward = self.turn_reward

        else:
            # reward = -1*self.end_episode_points
            reward = -200
            # self.goal_x, self.goal_y = self.respawn_goal.getPosition(True, delete=True)
        # distant_rate = round(observations[0][361],3)
        # print('this is distant: '+str(distant_rate))
        # if self.cumulated_reward > 30:
        #     self.goal_x, self.goal_y = self.respawn_goal.getPosition(True, delete=True)
        # else:
        rospy.logdebug("reward=" + str(reward))
        self.cumulated_reward += reward
        rospy.logdebug("Cumulated_reward=" + str(self.cumulated_reward))
        self.cumulated_steps += 1
        rospy.logdebug("Cumulated_steps=" + str(self.cumulated_steps))
        # reward = round(reward, 3)
        return reward


    # Internal TaskEnv Methods
    
    def discretize_observation(self,laser_data,number_of_sectors):
        """
        Discards all the laser readings that are not multiple in index of number_of_sectors
        value.
        """

        base = len(laser_data.ranges)/number_of_sectors
        current_sector = -1
        
        sector_readings = [self.safe_laser_value]*number_of_sectors
        
        for i, item in enumerate(laser_data.ranges):
            #rospy.logwarn("#### S ###")
            #rospy.logwarn(str(i))
            #rospy.logwarn(str(item))
            rest_is_zero = (i%base==0)
            
            if rest_is_zero:
                # rospy.logwarn("CHANGE SECTOR="+str(rest_is_zero))
                current_sector += 1
            else:
                rospy.loginfo("NO CHANGE SECTOR="+str(rest_is_zero))
                
            
            if numpy.isnan(item):
                rospy.logerr(">>>>>>>>>>>>NAN VALUE=>>>"+str(item))
            
            elif (self.min_range >= item ):
                sector_readings[current_sector] = self.danger_laser_value
            
            elif (self.middle_range >= item > self.min_range):
                sector_readings[current_sector] = self.middle_laser_value


        return sector_readings
        
        
    def check_laser_sector_readings_safe(self, laser_sector_readings):
        """
        Checks if all the sector readings have the self.safe_laser_value
        of self.middle_laser_value
        """
        
        readings_safe = all((c >= self.danger_laser_value) for c in laser_sector_readings)
        # rospy.logwarn("laser_sector_readings=>>>"+str(laser_sector_readings))
        # rospy.logwarn("readings_safe=>>>"+str(readings_safe))
        
        return readings_safe

    def get_last_action(self):
        return self.last_action


    def create_goal(self):
        self.goal_x, self.goal_y = self.respawn_goal.getPosition(True, delete=True)

    # def _reset_sim(self):

# if __name__=='__main__':
#     arr = [1,2,3,4]
#     arr = np.array(arr)
#     arr= np.reshape(arr,(1,-1))
#     print(arr)
#     print(arr.shape)
#     arr2 = np.reshape(arr,(4))
#     print(arr2)