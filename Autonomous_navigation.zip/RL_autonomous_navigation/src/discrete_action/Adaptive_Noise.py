class AdaptNoisyLinear(Module):
    def __init__(self, in_features, out_features, threshold, bias = True, std_init = .1, adaptation_coefficient = 1.01):
        super(AdaptNoisyLinear, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.include_bias = bias
        self.threshold = threshold
        self.sigma = std_init
        self.placeholder_sigma = std_init
        self.adaptation_coefficient = adaptation_coefficient
        self.weight_mu = Parameter(torch.Tensor(out_features, in_features))
        self.register_buffer('weight_epsilon', torch.Tensor(out_features, in_features))
        if self.include_bias:
            self.bias_mu = Parameter(torch.Tensor(out_features))
            self.register_buffer('bias_epsilon', torch.Tensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.noisy = True
        self.resample()

    def update_threshold(self, new_threshold):
        self.threshold = new_threshold

    def adapt(self, distance):
        if (distance > self.threshold).all():
            self.sigma /= self.adaptation_coefficient
            self.placeholder_sigma /= self.adaptation_coefficient
        else:
            self.sigma *= self.adaptation_coefficient
            self.placeholder_sigma *= self.adaptation_coefficient

    def denoise(self):
        self.noisy = False

    def renoise(self):
        self.noisy = True

    def resample(self):
        self.weight_epsilon.normal_()
        if self.include_bias:
            self.bias_epsilon.normal_()

    def forward(self, input):
        if self.noisy:
            return F.linear(input,
                self.weight_mu + Variable(self.sigma * self.weight_epsilon),
                self.bias_mu + Variable(self.sigma * self.bias_epsilon))
        else:
            return F.linear(input, self.weight_mu, self.bias_mu)

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
            + str(self.in_features) + ' -> ' \
            + str(self.out_features)