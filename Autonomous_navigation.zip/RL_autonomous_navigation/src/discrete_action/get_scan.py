import rospy
from sensor_msgs.msg import LaserScan
from move_base_msgs.msg import MoveBaseActionGoal
from geometry_msgs.msg import PoseWithCovarianceStamped
from geometry_msgs.msg import Pose
import numpy as np
from tf.transformations import euler_from_quaternion
import math
from math import pi
import gym
from Configuration import my_turtlebot2_maze
from src.discrete_action.ackt.acktr import learn
import tensorflow as tf
from ackt.acktr import Model
from src.discrete_action.ackt.Helper_function import build_policy
from geometry_msgs.msg import Twist
from src.discrete_action.Configuration.respawnGoal import Respawn

class Env(object):
    def __init__(self):
        self.action_space = 5
        self.observation_space =12



# #
def set_param(ros):
    ros.set_param("/turtlebot2/n_actions", 5)
    ros.set_param("/turtlebot2/alpha", alpha)
    ros.set_param("/turtlebot2/epsilon", epsilon)
    ros.set_param("/turtlebot2/gamma", gamma)
    ros.set_param("/turtlebot2/epsilon_discount", epsilon_discount)
    ros.set_param("/turtlebot2/nepisodes", nepisodes)
    ros.set_param("/turtlebot2/nsteps", nstep)
    ros.set_param("/turtlebot2/running_step", running_steps)
    ros.set_param("/turtlebot2/linear_forward_speed", 0.5)
    ros.set_param("/turtlebot2/linear_turn_speed", 0.1)
    ros.set_param("/turtlebot2/angular_speed", 0.3)
    ros.set_param("/turtlebot2/init_linear_forward_speed", 0.0)
    ros.set_param("/turtlebot2/init_linear_turn_speed", 0.0)
    ros.set_param("/turtlebot2/new_ranges", 5)
    ros.set_param("/turtlebot2/min_range", 0.5)
    ros.set_param("/turtlebot2/max_laser_value", 6.0)
    ros.set_param("/turtlebot2/min_laser_value", 0.0)

    ros.set_param("/turtlebot2/number_of_sectors", 3)
    ros.set_param("/turtlebot2/min_range", 0.5)
    ros.set_param("/turtlebot2/middle_range", 1.0)
    ros.set_param("/turtlebot2/danger_laser_value", 2)
    ros.set_param("/turtlebot2/middle_laser_value", 1)
    ros.set_param("/turtlebot2/safe_laser_value", 0)
    ros.set_param("/turtlebot2/forwards_reward", 5)
    ros.set_param("/turtlebot2/turn_reward", 1)
    ros.set_param("/turtlebot2/end_episode_points", 200)

class Observation(object):

    def __init__(self):
        # self.scan = [0 for i in range(10)]
        self.pose = Pose()
        self.goal = MoveBaseActionGoal()



        self.pub_goal11 = rospy.Publisher('/move_base/goal', MoveBaseActionGoal, queue_size=10)
        # self.pub_goal()
        rospy.Subscriber('/scan', LaserScan, self.get_scan)
        rospy.Subscriber('/move_base/goal', MoveBaseActionGoal, self.get_goal)
        rospy.Subscriber('/amcl_pose', PoseWithCovarianceStamped, self.get_pose)
        # rospy.spin()

    def get_data_scan(self):
        return self.scan

    def get_pose(self, msg):
        self.pose = msg.pose.pose

    def get_goal(self, msg):
        self.goal = msg
        # goal_pose = self.

    # function get scan laser and transform to sparse scan
    def get_scan(self, msg):
        # print msg
        laser_scan = msg.ranges
        index = np.asarray([i*18 for i in range(5)])
        index = np.concatenate([index, np.asarray([i*18 for i in range(15, 20)])])
        # # print index
        #
        laser_scan = np.asarray(laser_scan)
        laser_scan = np.take(laser_scan, index)
        self.scan = laser_scan

        # print self.data

    def get_obs(self):
        self._check_laser_scan_ready()
        # self._check_goal()
        position_robot = self.pose.position
        position_goal = self.goal.goal.target_pose.pose.position
        orientation = self.pose.orientation
        orientation_list = [orientation.x, orientation.y, orientation.z, orientation.w]
        _, _, yaw = euler_from_quaternion(orientation_list)
        scan = self.scan

        ## compute the angle between goal and robot head
        goal_angle = math.atan2(position_goal.y - position_robot.y, position_goal.x - position_robot.x)
        heading = goal_angle - yaw
        if heading > pi:
            heading -= 2 * pi

        elif heading < -pi:
            heading += 2 * pi
        heading = round(heading, 3)

        ##compute the distance between robot and goal
        distance = round(math.hypot(position_goal.x - position_robot.x, position_goal.y - position_robot.y), 2)

        obs = np.asarray(scan)
        obs = [min(3.5, obs[i]) for i in range(len(scan))]
        obs = np.reshape(obs, (1, 10))

        result = np.concatenate((obs, np.array([[heading, distance]])), axis=1)
        return result



    def pub_goal(self):
        goal_des = MoveBaseActionGoal()
        goal_des.goal.target_pose.header.frame_id = "map"
        goal_des.goal.target_pose.pose.position.x = 1.5
        goal_des.goal.target_pose.pose.position.y = 1
        goal_des.goal.target_pose.pose.orientation.w = 0.6
        goal_des.goal.target_pose.pose.orientation.z = 0.8
        self.goal = goal_des
        self.pub_goal11.publish(goal_des)

    def _check_laser_scan_ready(self):
        self.laser_scan = None
        rospy.logdebug("Waiting for /kobuki/laser/scan to be READY...")
        while self.laser_scan is None and not rospy.is_shutdown():
            try:
                self.laser_scan = rospy.wait_for_message("/scan", LaserScan, timeout=5.0)
                rospy.logdebug("Current /kobuki/laser/scan READY=>")

            except:
                rospy.logerr("Current /kobuki/laser/scan not ready yet, retrying for getting laser_scan")
        return self.laser_scan

    def _check_goal(self):
        self.goal = None
        rospy.logdebug("Waiting for /kobuki/laser/scan to be READY...")
        while self.goal is None and not rospy.is_shutdown():
            try:
                self.goal = rospy.wait_for_message("/move_base/goal", LaserScan, timeout=5.0)
                # self.goal = goal.goal.target_pose.pose
                rospy.logdebug("Current goal has not published yet=>")

            except:
                rospy.logerr("Current goal has not published yet")
        return self.goal


# def call_back(msg):
#     print msg.ranges

def set_action(action):
    velocity = 0.2
    angular = 0
    pub_cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
    if action == 2:  # FORWARD
        # linear_speed = self.linear_forward_speed
        angular_speed = 0.0
        print 'MOVE FORWARD'
    elif action < 2:  # LEFT
        # linear_speed = self.linear_turn_speed
        angular_speed = (action - 2) * pi / 8
        print "TURN_LEFT"
    elif action > 2:  # RIGHT
        # linear_speed = self.linear_turn_speed
        angular_speed = (action - 2) * pi / 8
        print "TURN_RIGHT"
    cmd = Twist()
    cmd.angular.z = angular_speed
    cmd.linear.x =velocity
    pub_cmd_vel.publish(cmd)

def set_stay_action():
    velocity = 0
    angular_speed = 0
    pub_cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
    cmd = Twist()
    cmd.angular.z = angular_speed
    cmd.linear.x = velocity
    pub_cmd_vel.publish(cmd)

if __name__ == '__main__':

    alpha = 1.0
    epsilon = 0.9
    gamma = 0.7
    epsilon_discount = 0.99
    nepisodes = 500
    nstep = 0

    running_steps = 0.1
    wait_time = 0.2

    #
    rospy.init_node('example_a2c', anonymous=True, log_level=rospy.WARN)
    set_param(rospy)
    # rospack = rospkg.RosPack()
    # pkg_path = rospack.get_path('turtle2_openai_ros_example')
    # outdir = pkg_path + '/training_result'
    # policy = 0
    # env = Env()
    # env.action_space
    env = gym.make('MyTurtleBot2Maze-v0')
    ##################33-------------------###########33
    nenvs = 1
    ob_space = env.observation_space
    ac_space = env.action_space
    total_timesteps = int(1e6)
    gamma = 0.99
    log_interval = 10
    nprocs = 32
    nsteps = 5,
    ent_coef = 0.01
    vf_coef = 0.5
    vf_fisher_coef = 1.0
    lr = 0.25
    max_grad_norm = 0.5,
    kfac_clip = 0.001
    save_interval = 10
    lrschedule = 'linear'
    load_path = None
    is_async = True
    ###########################----------------------------------
    # model = learn(env=env, seed=1234, network='mlp')
    policy = build_policy(env, policy_network='mlp')
    model = Model(policy, ob_space, ac_space, nenvs, total_timesteps, nprocs=nprocs, nsteps
    =nsteps, ent_coef=ent_coef, vf_coef=vf_coef, vf_fisher_coef=
                  vf_fisher_coef, lr=lr, max_grad_norm=max_grad_norm, kfac_clip=kfac_clip,
                  lrschedule=lrschedule, is_async=is_async)
    graph = tf.get_default_graph()
    sess = tf.get_default_session()
    model_path = '/home/manhlt/Desktop/checkpoint259682'
    model.load(model_path)
    rospy.init_node('scan_values')
    obs = Observation()
    r = rospy.Rate(3)

    respawn_goal = Respawn()
    # respawn_goal.respawnModel_2(1.5,1)
    loop = True
    while loop:

        # print laser.data
        print '------------------------ Goal'
        # print obs.get_obs()
        aa = obs.get_obs()
        # print aa
        print aa
        # if aa[0][11] > 0.2:
        if True:
            x = obs.goal.goal.target_pose.pose.position.x
            y = obs.goal.goal.target_pose.pose.position.y
            respawn_goal.respawnModel_2(x, y)
            while True:
                aa = obs.get_obs()
                action = model.train_model.predict_action(aa)
                print 'action: ',action
                set_action(action)
                r.sleep()
                if aa[0][11] < 0.2:
                    respawn_goal.deleteModel()
                    break

        set_stay_action()


