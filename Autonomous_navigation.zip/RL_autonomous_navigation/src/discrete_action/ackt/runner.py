import numpy as np
# from baselines.a2c.utils import discount_with_dones
# from baselines.common.runners import AbstractEnvRunner


import numpy as np
from abc import ABCMeta, abstractmethod


def discount_with_dones(rewards, dones, gamma):
    discounted = []
    r = 0
    for reward, done in zip(rewards[::-1], dones[::-1]):
        r = reward + gamma * r * (1. - done)  # fixed off by one bug
        discounted.append(r)
    return discounted[::-1]


class AbstractEnvRunner(object):
    __metaclass__ = ABCMeta

    def __init__(self, env, model, nsteps):
        self.env = env
        self.model = model
        self.nenv = nenv = env.num_envs if hasattr(env, 'num_envs') else 1
        # self.batch_ob_shape = (nenv * nsteps,) + env.observation_space.shape
        self.batch_ob_shape = (-1, ) + env.observation_space.shape
        self.obs = np.zeros((nenv,) + env.observation_space.shape, dtype=env.observation_space.dtype.name)
        self.test_obs = env.reset()
        self.obs[:] = self.test_obs
        self.nsteps = nsteps
        self.states = model.initial_state
        self.dones = [False for _ in range(nenv)]

    @abstractmethod
    def run(self):
        raise NotImplementedError


class Runner(AbstractEnvRunner):
    """
    We use this class to generate batches of experiences

    __init__:
    - Initialize the runner

    run():
    - Make a mini batch of experiences
    """

    def __init__(self, env, model, nsteps=5, gamma=0.99):
        super(Runner, self).__init__(env=env, model=model, nsteps=nsteps)
        self.gamma = gamma
        self.batch_action_shape = [x if x is not None else -1 for x in model.train_model.action.shape.as_list()]
        self.ob_dtype = model.train_model.X.dtype.as_numpy_dtype

    def run(self):
        # We initialize the lists that will contain the mb of experiences
        batch_reward = 0
        mb_obs, mb_rewards, mb_actions, mb_values, mb_dones = [], [], [], [], []
        mb_states = self.states
        for n in range(self.nsteps):
            # Given observations, take action and value (V(s))
            # We already have self.obs because Runner superclass run self.obs[:] = env.reset() on init
            actions, values, states, _, pd = self.model.step(self.obs, S=self.states, M=self.dones)
            print 'Current policy: ', np.exp(pd)/np.sum(np.exp(pd))
            # Append the experiences
            mb_obs.append(np.copy(self.obs))
            mb_actions.append(actions)
            mb_values.append(values)
            mb_dones.append(self.dones)

            # Take actions in env and look the results
            obs, rewards, dones, _ = self.env.step(actions)
            batch_reward+=rewards
            # print('bosssssssssssss',obs)
            # print('rewards:', rewards)
            # print('Obs: ', self.obs[0][11])
            # print('Inital OBS: ', self.test_obs[0][11])
            self.states = states
            self.dones = dones
            self.obs = obs
            mb_rewards.append(rewards)
            if dones:
                print('--------------RESET-----------------------------------------')
                self.obs = self.env.reset()

                break
        mb_dones.append(self.dones)

        # Batch of steps to batch of rollouts
        mb_obs = np.asarray(mb_obs, dtype=self.ob_dtype).swapaxes(1, 0).reshape(self.batch_ob_shape)
        # print 'dones',mb_dones
        # mb_rewards = np.asarray(mb_rewards, dtype=np.float32)
        # print('mb_reward',mb_rewards)
        # print('mb_masks',mb_masks)
        # mb_rewards = np.asarray(mb_rewards, dtype=np.float32).swapaxes(1, 0)
        mb_rewards = np.asarray(mb_rewards, dtype=np.float32).reshape((1, -1))
        mb_actions = np.asarray(mb_actions, dtype=self.model.train_model.action.dtype.name).swapaxes(1, 0)
        mb_values = np.asarray(mb_values, dtype=np.float32).swapaxes(1, 0)
        mb_dones = np.asarray(mb_dones, dtype=np.bool).reshape(1, -1)
        # mb_dones = np.asarray(mb_dones, dtype=np.bool).swapaxes(1, 0)
        mb_masks = mb_dones[:, :-1]
        mb_dones = mb_dones[:, 1:]
        # mb_masks = mb_dones[:-1]
        # mb_dones = mb_dones[1:]
        if self.gamma > 0.0:
            # Discount/bootstrap off value fn
            last_values = self.model.value(self.obs, S=self.states, M=self.dones).tolist()
            for n, (rewards, dones, value) in enumerate(zip(mb_rewards, mb_dones, last_values)):
                rewards = rewards.tolist()
                dones = dones.tolist()
                if dones[-1] == 0:
                    rewards = discount_with_dones(rewards + [value], dones + [0], self.gamma)[:-1]
                else:
                    rewards = discount_with_dones(rewards, dones, self.gamma)

                mb_rewards[n] = rewards
        mb_actions_size = mb_obs.shape[0]

        # mb_actions = mb_actions.reshape(self.batch_action_shape)
        mb_actions = mb_actions.reshape(mb_actions_size)

        mb_rewards = mb_rewards.flatten()
        mb_values = mb_values.flatten()
        mb_masks = mb_masks.flatten()
        return mb_obs, mb_states, mb_rewards, mb_masks, mb_actions, mb_values, mb_dones, batch_reward
