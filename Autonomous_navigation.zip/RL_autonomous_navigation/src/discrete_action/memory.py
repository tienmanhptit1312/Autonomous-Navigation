from collections import namedtuple
from collections import deque
import random
import numpy as np

Transition = namedtuple("Transition",['state','action','reward','next_state','done'])

class Buffer_Memory(object):
    def __init__(self, buffer_length=1000000, batch_size=30, seed=123):
        self.buffer_length = buffer_length
        self.batch_size=batch_size
        self.buffer = deque()
        self.count = 0
        np.random.seed(seed)


    def add(self,state, action, reward, next_state, done):
        experience = (state, action, reward, next_state, done)
        if self.count < self.buffer_length:
            # self.buffer.appendleft(Transition(state=state, action=action, reward=reward, next_state=next_state, done=done))
            self.buffer.append(experience)
            self.count += 1
        else:
            self.buffer.popleft()
            self.buffer.append(experience)

    def get_batch(self):
        batch = []
        if len(self.buffer) < self.batch_size:
            batch = self.buffer
        else:
            batch = random.sample(self.buffer, self.batch_size)
        state_batch = [x[0] for x in batch]
        action_batch = [x[1] for x in batch]
        reward_batch = [x[2] for x in batch]
        next_state_batch = [x[3] for x in batch]
        done_batch = [x[4] for x in batch]
        return state_batch, action_batch, reward_batch, next_state_batch, done_batch

    def clear(self):
        self.buffer.clear()

    def get_size(self):
        return self.count


if __name__=='__main__':
    l = [1,2,3,4,5,6,7]
    rd = np.random.choice(l,3,replace=False)
    print(rd)
    l.pop(0)
    l.append(8)
    print(l)

    # # compute the estimator value of s_batch and action_batch
    # estimator_value = critic.predict(state=s_batch, action=action_batch)
    # td = y_i - estimator_value
