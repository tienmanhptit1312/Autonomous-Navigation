import tensorflow as tf
import numpy as np
import math
import keras.backend as k
from keras.initializers import normal, identity
from keras.models import  Sequential, Model, model_from_json
from keras.layers import Dense, Flatten, Input, merge, Lambda, Add
from keras.optimizers import Adam
from keras.initializers import he_normal
import tflearn

SEED = 100

class Critic(object):
    def __init__(self, sess, num_trainable_vars, init,learning_rate=1e-04, scope_name='value_estimator', num_actor_var=0, tau=0.001,
                 gamma=0.99,):
        tf.random.set_random_seed(SEED)
        with tf.variable_scope(scope_name):
            self.learning_rate = learning_rate
            self.tau = tau
            self.gamma = gamma
            self.sess = sess
            self.action_dim = 1
            self.s_dim= 12
            self.num_trainable_vars = num_trainable_vars
            self.init_var = init
            self.batch_size = 40
            k.set_session(sess)
            #create the critic_model
            self.inputs, self.actions, self.network_out = self.create_network()
            self.weights = tf.trainable_variables()[self.num_trainable_vars:]


            #create the critic_target_model
            self.target_inputs, self.target_actions, self.target_network_out = self.create_network()
            self.target_weights = tf.trainable_variables()[ (len(self.weights)+self.num_trainable_vars):]

            # #create pertubed network
            # self.pertubed_inputs, self.pertuberd_network_out = self.create_network()
            # self.pertubed_weights = tf.trainable_variables()[(len(self.weights) + self.num_trainable_vars + len(self.target_weights)):]
            #
            # self.update_pertubed = [self.pertubed_weights[i].assign(self.weights[i]) for i in
            #                         range(len(self.pertubed_weights))]

            #update target_network
            self.update = \
                [self.target_weights[i].assign(tf.multiply(self.weights[i], self.tau) +
                                               tf.multiply(self.target_weights[i], 1 - self.tau))
                 for i in range(len(self.target_weights))]

            self.update_2 = \
                [self.target_weights[i].assign(self.weights[i]) for i in range(len(self.target_weights))]

            self.predicted_q_value = tf.placeholder(dtype=tf.float32, shape=(None, 1))
            self.loss = tf.reduce_mean(tf.square(tf.subtract(self.network_out, self.predicted_q_value)))
            self.optimize = tf.train.AdamOptimizer(self.learning_rate).minimize(self.loss)



            self.action_grads = tf.gradients(self.network_out, self.actions)

            if self.init_var == True:
                self.sess.run(tf.global_variables_initializer())

    def create_network(self):
        inputs = tf.placeholder(dtype=tf.float32, shape=(None, self.s_dim))
        actions = tf.placeholder(dtype=tf.float32, shape=(None, self.action_dim))
        # concat_layer = tf.keras.layers.concatenate([actions, inputs], axis=-1)
        layer_1 = tf.layers.dense(
            inputs= inputs,
            units= 400,
            activation=tf.nn.elu,
            # kernel_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None),
            # bias_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None)
            kernel_initializer=tf.keras.initializers.he_uniform(),
            bias_initializer=tf.keras.initializers.he_uniform()
        )
        # concat_layer = tf.keras.layers.concatenate([layer_1, actions])
        normalize = tflearn.layers.normalization.batch_normalization(layer_1)
        layer_2 = tf.layers.dense(
            inputs= normalize,
            units= 300,
            # kernel_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None),
            # bias_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None)
            kernel_initializer=tf.keras.initializers.he_uniform(),
            bias_initializer=tf.keras.initializers.he_uniform(),
            activation=tf.nn.elu
        )
        layer_2_action = tf.layers.dense(
            inputs = actions,
            units= 300,
            # kernel_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None),
            # bias_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None)
            kernel_initializer=tf.keras.initializers.he_uniform(),
            bias_initializer=tf.keras.initializers.he_uniform()
        )
        merge_layer = tf.keras.layers.add([layer_2, layer_2_action])
        # normalize_1 = tflearn.layers.normalization.batch_normalization(merge_layer)
        output = tf.layers.dense(
            inputs= merge_layer,
            units=1,
            kernel_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None),
            bias_initializer=tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003, seed=None),
            # kernel_initializer=tf.keras.initializers.he_uniform(),
            # bias_initializer=tf.keras.initializers.he_uniform(),
            # activation=tf.identity
        )

        return inputs, actions, output

    def train(self, state, action, predicted_q):
        _, loss=self.sess.run([self.optimize,self.loss], feed_dict={
            self.inputs: state,
            self.actions: action,
            self.predicted_q_value: predicted_q
        })
        return loss

    def gradients(self, state, action):
        gradient = self.sess.run(self.action_grads, feed_dict={
            self.inputs: state,
            self.actions: action
        })[0]
        return gradient

    # def pertub_param(self, stddev):
    #
    #     pertub_ops = [tf.assign(self.pertubed_weights[i], self.pertubed_weights[i]+
    #                             tf.random_normal(mean=0, shape=tf.shape(self.pertubed_weights[i]), stddev=stddev))
    #                   for i in range(len(self.pertubed_weights))]
    #     self.sess.run(pertub_ops)

    def update_target_network(self):

        self.sess.run(self.update)

    def update_target_network_2(self):

        self.sess.run(self.update_2)

    def predict(self, states, actions):
        result = self.sess.run(self.network_out, feed_dict={
            self.inputs: states,
            self.actions: actions
        })
        return result
    def predict_target(self,states, actions):
        result = self.sess.run(self.target_network_out, feed_dict={
            self.target_inputs: states,
            self.target_actions: actions
        })
        return result