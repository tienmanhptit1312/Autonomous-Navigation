import numpy as np
import tensorflow as tf
import math
SEED = 1234
import time

class Actor(object):
    def __init__(self, sess, name_scope='policy_estimator'):
        tf.random.set_random_seed(SEED)
        with tf.variable_scope(name_scope):
            self.sess = sess
            # self.init = tf.global_variables_initializer()
            # self.sess.run(self.init)
            self.state = tf.placeholder(dtype=tf.float16, shape=(None, 360), name='state')
            self.td = tf.placeholder(dtype=tf.float16, shape=(None, 1), name='TD')
            self.action_prob = self.create_network()
            self.picked_action_prob = tf.math.reduce_max(self.action_prob, axis=1)
            self.loss = -tf.log(self.picked_action_prob) * self.td
            self.loss = tf.reduce_mean(self.loss)

            self.optimizer = tf.train.AdadeltaOptimizer(learning_rate=0.0001)
            self.train_op = self.optimizer.minimize(self.loss)

    def predict(self, state):
        sess = tf.get_default_session()
        action_predict, action_probs = sess.run([self.picked_action_prob,self.action_prob], feed_dict={self.state: state})
        print(sess.run(self.state, feed_dict={self.state: state}))
        print('action probs'+str(action_probs))
        return action_probs, action_predict

    def learn(self, td, action, state):
        sess = tf.get_default_session()
        _, loss = sess.run([self.train_op, self.loss], feed_dict={self.state: state, self.td: td, self.action: action})
        return loss

    def create_network(self):
        # self.sess.run(tf.global_variables_initializer())
        layer_1 = tf.layers.dense(
            inputs=self.state,
            units=200,
            kernel_initializer=tf.keras.initializers.he_normal(),
            activation=tf.nn.relu
        )
        # layer_1 = tf.layers.dense(self.state, 3, tf.nn.relu)
        # # layer_1 = tf.nn.relu(layer_1)
        layer_2 = tf.layers.dense(
            inputs=layer_1,
            units=200,
            kernel_initializer=tf.keras.initializers.he_normal(),
            activation=tf.nn.relu
        )
        # # # layer_2 = tf.nn.relu(layer_2)
        layer_3 = tf.layers.dense(
            inputs= layer_2,
            units=20,
            kernel_initializer=tf.keras.initializers.he_normal(),
            activation=tf.nn.relu
        )
        # # # layer_3 = tf.nn.relu(layer_3)
        output_layer = tf.layers.dense(
            inputs=layer_3,
            units=3
        )
        result = tf.nn.softmax(output_layer)
        # result = result
        # action = tf.arg_max(result, dimension=1)
        return result

class OrnsteinUhlenbeckActionNoise:
    def __init__(self, mu, sigma=0.3, theta=.15, dt=1e-2, x0=None):
        self.theta = theta
        self.mu = mu
        self.sigma = sigma
        self.dt = dt
        self.x0 = x0
        self.reset()

    def __call__(self):
        x = self.x_prev + self.theta * (self.mu - self.x_prev) * self.dt + \
                self.sigma * np.sqrt(self.dt) * np.random.normal(size=1)
        self.x_prev = x
        return x

    def reset(self):
        self.x_prev = self.x0 if self.x0 is not None else np.zeros_like(self.mu)

    def __repr__(self):
        return 'OrnsteinUhlenbeckActionNoise(mu={}, sigma={})'.format(self.mu, self.sigma)

if __name__=='__main__':

    env = {'observatio_space':12, 'action_space':5}
    # print env.
    # t1 = time.time()
    # time.sleep(3)
    # t2 = time.time()
    # result = t2 - t1
    # print(result)
