import tensorflow as tf
from keras.models import Sequential
from keras.layers import Dense, Conv1D, Dropout, Flatten, Activation
from keras.utils import np_utils
from collections import namedtuple
import numpy as np
import math
import itertools
from .memory import Buffer_Memory

SEED = 100

EpisodeStats = namedtuple("Stats", ['episode_length', 'episode_reward'])


class Actor(object):
    def __init__(self, learning_rate=0.01, name_scope='policy_estimator', low=0, high=2 * math.pi, tau=0.001, sess=None):
        tf.random.set_random_seed(SEED)
        with tf.variable_scope(name_scope):
            self.model = Sequential()
            self.sess = sess
            self.state = tf.placeholder(dtype=tf.float16, shape=(None, 300), name='state')
            self.td = tf.placeholder(dtype=tf.float32, name='TD')
            self.low = low
            self.high = high
            self.tau = tau
            # actor network
            self.action, self.norm_dist = self.create_network()
            self.network_param = tf.trainable_variables()

            # target network
            self.action_target, self.norm_dist_target = self.create_network()
            self.target_network_param = tf.trainable_variables()[len(self.network_param):]

            # update the parameter of target network
            self.update_target_network()

            # loss and train op
            self.loss = -self.norm_dist.log_prob(self.action) * self.td
            self.cross_entropy = self.norm_dist.entropy()
            self.loss -= self.cross_entropy
            self.loss = tf.reduce_mean(self.loss)

            self.optimizer = tf.train.AdadeltaOptimizer(learning_rate=learning_rate)
            self.train_op = self.optimizer.minimize(self.loss,
                                                    global_step=tf.train.get_global_step(),
                                                    var_list=[self.network_param])
            self.num_trainable_var = len(self.network_param) + len(self.target_network_param)

    def predict(self, state):
        # sess = sess or tf.get_default_session()
        return self.sess.run(self.action, feed_dict={self.state: state})

    def predict_target(self, state):
        # sess = sess or tf.get_default_session()
        return self.sess.run(self.action_target, feed_dict={self.state: state})

    def learn(self, td, action, state):
        # sess = sess or tf.get_default_session()
        _, loss = self.sess.run([self.train_op, self.loss],
                                feed_dict={self.state: state, self.td: td, self.action: action})
        return loss

    def create_network(self):
        mu = tf.layers.dense(inputs=self.state,
                             units=1,
                             kernel_initializer=tf.keras.initializers.he_normal(),
                             activation=tf.nn.relu)

        sigma = tf.layers.dense(inputs=self.state,
                                units=1,
                                kernel_initializer=tf.keras.initializers.he_normal(),
                                activation=tf.nn.relu)
        sigma = tf.nn.softplus(sigma) + 1e-5
        norm_dist = tf.distributions.Normal(mu, sigma)
        action = self.norm_dist.sample(1)
        action = tf.clip_by_value(action, self.low, self.high)
        return action, norm_dist

    def update_target_network(self):
        self.update_target_network_param = \
            [self.target_network_param[i].assign(tf.multiply(self.tau, self.network_param[i]) +
                                                 tf.multiply(1 - self.tau, self.target_network_param[i]))
             for i in range(len(self.target_network_param))]
        self.sess.run(self.update_target_network_param)

    def get_trainable_var(self):
        return self.num_trainable_var


class Critic(object):
    def __init__(self, learning_rate=0.01, scope_name='value_estimator', num_actor_var=0, tau=0.001, gamma=0.99,
                 sess=None):
        tf.random.set_random_seed(SEED)
        with tf.variable_scope(scope_name):
            self.state = tf.placeholder(shape=(None, 300), dtype=tf.float16, name='state')
            self.target = tf.placeholder(shape=(None, 1), dtype=tf.float32, name='target')
            self.chosen_action = tf.placeholder(shape=(None, 1), dtype=tf.float32, name='chosen_action')
            self.num_actor_var = num_actor_var
            self.tau = tau
            self.gamma = gamma
            self.sess = sess

            # critic network
            self.value_estimate = self.create_network()
            self.network_param = tf.trainable_variables()[self.num_actor_var:]

            # target_network
            self.target_value_estimate = self.create_network()
            self.target_network_param = tf.trainable_variables()[len(self.network_param) + self.num_actor_var:]

            self.update_target_network()

            self.loss = tf.squared_difference(self.value_estimate, self.target)
            self.loss = tf.reduce_mean(self.loss)
            self.optimizer = tf.train.AdadeltaOptimizer(learning_rate=learning_rate)
            self.train_op = self.optimizer.minimize(self.loss,
                                                    global_step=tf.train.get_global_step(),
                                                    var_list=[self.network_param])

    def predict(self, state, action):
        # sess = sess or tf.get_default_session()
        return self.sess.run(self.value_estimate, feed_dict={self.state: state, self.chosen_action: action})

    def predict_target(self, state, action):
        return self.sess.run(self.target_value_estimate, feed_dict={self.state: state, self.chosen_action: action})

    def learn(self, state, target, action):
        # sess = sess or tf.get_default_session()
        _, loss = self.sess.run([self.train_op, self.loss],
                                feed_dict={self.state: state, self.target: target, self.chosen_action: action})
        return loss

    def create_network(self):
        layer_1= tf.layers.dense(
            inputs=self.state,
            units=200,
            kernel_initializer=tf.keras.initializers.he_normal(),
            activation=tf.nn.relu
        )
        action_layer = tf.layers.dense(
            input=self.chosen_action,
            unit=200,
            kernel_initializer=tf.keras.initializers.he_normal(),
            activation=tf.nn.relu
        )
        pair_action_value = tf.concat([layer_1, action_layer], axis=1)
        value_estimate = tf.layers.dense(
            inputs=pair_action_value,
            units=1,
            kernel_initializer=tf.keras.initializers.he_normal()
        )
        return value_estimate

    def update_target_network(self):
        self.update_target_network_param = \
            [self.target_network_param[i].assign(tf.multiply(self.tau, self.network_param[i]) +
                                                 tf.multiply(1 - self.tau, self.target_network_param[i]))
             for i in range(len(self.target_network_param))]
        self.sess.run(self.update_target_network_param)


def build_summaries():
    episode_reward = tf.Variable(0.)
    tf.summary.scalar('Reward', episode_reward)
    episode_critic_loss = tf.Variable(0.)
    tf.summary.scalar('Critic_loss', episode_critic_loss)
    episode_actor_loss = tf.Variable(0.)
    tf.summary.scalar('Actor_loss', episode_actor_loss)

    summary_vars = [episode_reward, episode_critic_loss, episode_actor_loss]
    summary_ops = tf.summary.merge_all()
    return summary_ops, summary_vars


def a2c(actor, critic, env, sess, actor_noise, args, discount_factor=0.99):
    # stats = EpisodeStats(
    #     episode_length=np.zeros(num_episodes),
    #     episode_reward=np.zeros(num_episodes)
    # )
    summary_ops, summary_vars = build_summaries()
    sess.run(tf.global_variables_initializer())
    writer = tf.summary.FileWriter(args['summary_dir'],sess.graph)

    actor.update_target_network()
    critic.update_target_network()
    batch_size = int(args['minibatch_size'])
    replay_buffer = Buffer_Memory(batch_size= batch_size)
    Transition = namedtuple("Transition", ['state', 'action', 'reward', 'next_state'])

    for i_ep in range(int(args['max_episode'])):
        state = env.reset()
        ep_reward = 0
        ep_critic_loss = 0
        ep_actor_loss = 0
        episode = []
        for t in itertools.count():
            action = actor.predict(state) + actor_noise()
            next_state, reward, done, _ = env.step(action)
            replay_buffer.add(state, action, reward, next_state, done)

            if replay_buffer.get_size() > batch_size:
                s_batch, action_batch, reward_batch, next_state_batch = replay_buffer.get_batch()

                #calculate the Q-target
                next_state_batch = np.array(next_state_batch)
                next_state_batch = np.reshape(next_state_batch, (batch_size, 300))
                target_action_batch = actor.predict_target(next_state_batch)
                target_action_batch = tf.reshape(target_action_batch, (batch_size, 1))
                target_q = critic.predict_target(next_state_batch, target_action_batch)

                y_i = []
                for k in range (0,batch_size):
                    if done[k]:
                        y_i.append(reward_batch[k])
                    else:
                        y_i.append(reward_batch[k] + critic.gamma*target_q[k])

                #update the critic network using TD
                s_batch = np.array(s_batch)
                s_batch = np.reshape(s_batch, (None,300))
                y_i = np.array(y_i) #array of TD value
                y_i = np.reshape(y_i, (None,1))
                action_batch = np.array(action_batch)
                action_batch = np.reshape(action_batch, (batch_size, 1))
                critic_loss = critic.learn(s_batch, target=y_i, action=action_batch)
                ep_critic_loss += critic_loss

                #update the actor network using sample gradient
                predict_action = actor.predict(state= s_batch)
                actor_loss=actor.learn(td=y_i, state=s_batch, action=predict_action)
                ep_actor_loss += actor_loss

                #update target network
                actor.update_target_network()
                critic.update_target_network()

            state = next_state
            ep_reward += reward

            if done:
                summary_stats = sess.run(summary_ops, feed_dict={
                    summary_vars[0]: ep_reward,
                    summary_vars[1]: ep_critic_loss,
                    summary_vars[2]: ep_actor_loss
                })
                writer.add_summary(summary_stats, i_ep)
                writer.flush()
                print('| Reward: {:d} | Episode: {:d} | Critic_loss: {:.4f} | Actor_loss: {:.4f}'\
                      .format(int(ep_reward), i_ep, ep_critic_loss, ep_actor_loss))
                break



if __name__ == '__main__':
    sess = tf.Session()
    init = tf.initialize_all_variables()
    sess.run(init)
    test = tf.nn.softplus(1.0)
    init_op = tf.initialize_all_variables()
    with tf.Session() as sess:
        sess.run(init_op)
        aa = sess.run(test)
        print(aa)
