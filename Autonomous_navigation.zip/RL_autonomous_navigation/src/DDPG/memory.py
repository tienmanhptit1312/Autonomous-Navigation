from collections import namedtuple
import random
import numpy as np
from pandas._libs.parsers import k

Transition = namedtuple("Transition",['state','action','reward','next_state','done'])

class Buffer_Memory(object):
    def __init__(self, buffer_length=10000, batch_size=30, seed=123):
        self.buffer_length = buffer_length
        self.batch_size=batch_size
        self.buffer = []
        np.random.seed(seed)


    def add(self,state, action, reward, next_state, done):
        if len(self.buffer) < self.buffer_length:
            self.buffer.append(Transition(state=state, action=action, reward=reward, next_state=next_state, done=done))
        else:
            self.buffer.pop(0)
            self.buffer.append(Transition(state=state, action=action, reward=reward, next_state=next_state, done=done))

    def get_batch(self):
        batch = []
        if len(self.buffer) < self.batch_size:
            batch = self.buffer
        else:
            batch = np.random.choice(self.buffer, 30, replace=False)
        state_batch = [x[0] for x in batch]
        action_batch = [x[1] for x in batch]
        reward_batch = [x[2] for x in batch]
        next_state_batch = [x[3] for x in batch]
        done_batch = [x[4] for x in batch]
        return state_batch, action_batch, reward_batch, next_state_batch, done_batch

    def clear(self):
        self.buffer.clear()

    def get_size(self):
        return len(self.buffer)


if __name__=='__main__':
    l = [1,2,3,4,5,6,7]
    rd = np.random.choice(l,3,replace=False)
    print(rd)
    l.pop(0)
    l.append(8)
    print(l)